export interface User {
  username: string;
  token: string;
}
