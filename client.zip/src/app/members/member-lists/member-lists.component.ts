import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-lists',
  templateUrl: './member-lists.component.html',
  styleUrls: ['./member-lists.component.css']
})
export class MemberListsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
